#!/bin/bash

rm -rf ~/ftpshare/*

rm ~/fftplog
