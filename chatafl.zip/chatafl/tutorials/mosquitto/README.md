## Download and compile mosquitto v2.0.7  
apt-get install libssl-dev libwebsockets-dev uuid-dev docbook-xsl docbook xsltproc  
cd $WORKDIR  
git clone https://github.com/eclipse/mosquitto.git  
cd mosquitto  
git checkout 2665705  
export AFL_USE_ASAN=1  
CFLAGS="-g -O0 -fsanitize=address -fno-omit-frame-pointer" LDFLAGS="-g -O0 -fsanitize=address -fno-omit-frame-pointer"  CC=afl-gcc make clean all WITH_TLS=no WITH_TLS_PSK:=no WITH_STATIC_LIBRARIES=yes WITH_DOCS=no WITH_CJSON=no WITH_EPOLL:=no  
## Fuzzing  
cd $WORKDIR/mosquitto  
afl-fuzz -d -i $AFLNET/tutorials/mosquitto/in-mqtt -o ./out-mqtt -m none -N tcp://127.0.0.1/1883 -P MQTT -D 10000 -q 3 -s 3 -E -K -R ./src/mosquitto  



##nanomq

mkdir build && cd build

export CC=afl-gcc
export CFLAGS="-g -O0 -fsanitize=address,undefined -fno-omit-frame-pointer"
export LDFLAGS="-fsanitize=address"

cmake .. -DWITH_TLS=OFF -DWITH_TLS_PSK=OFF -DWITH_STATIC_LIBRARIES=ON -DWITH_DOCS=OFF -DWITH_CJSON=OFF -DWITH_EPOLL=OFF

make -j128

afl-fuzz -d -i $AFLNET/tutorials/mosquitto/in-mqtt -o ./out-mqtt -m none -N tcp://127.0.0.1/1883 -P MQTT -D 10000 -q 3 -s 3 -E -K -R ./build/nanomq/nanomq start --conf /opt/nanomq/nanomq.conf


cmake .. -DCMAKE_C_COMPILER=afl-gcc -DCMAKE_CXX_COMPILER=afl-g++ -DCMAKE_CXX_FLAGS="-g -O0 -fsanitize=address,undefined -fno-omit-frame-pointer" -DCMAKE_EXE_LINKER_FLAGS="-fsanitize=address,undefined"

afl-fuzz -d -i $AFLNET/tutorials/mosquitto/in-mqtt -o ./out-mqtt -m none -N tcp://127.0.0.1/1883 -P MQTT -D 10000 -q 3 -s 3 -E -K -R ./build/flashmq 

afl-fuzz -d -i $AFLNET/tutorials/mosquitto/in-mqtt -o ./out-mqtt -m none -N tcp://127.0.0.1/1883 -P MQTT -D 10000 -q 3 -s 3 -E -K -R ./build/nanomq/nanomq start 

## In addition: Seeds generation  
You can refer to the script in this [repository](https://github.com/B1y0nd/mosquitto_seed) to generate more seeds.  
Support mqtt v3.1.1 and v5.  

/home/ubuntu/chatafl/afl-fuzz -d -i ./aflnet/tutorials/mosquitto/in-mqtt/ -o mqtt_out -N tcp://127.0.0.1/1883 -P MQTT -D 10000 -q 3 -s 3 -E -K -R -x /home/ubuntu/experiments/mqtt.dict -m none


afl-cov:
git clone https://github.com/mrash/afl-cov
复制目标程序源代码到新目录
对于 NanoMQ，使用 CMake: cmake .. -DCMAKE_C_FLAGS="-fprofile-arcs -ftest-coverage" 
make


wrapper.sh:
#!/bin/bash

# 参数1: gcov 版本 NanoMQ 可执行文件路径
SERVER=$1

# 参数2: 测试用例文件路径 (AFL_FILE)
TESTCASE=$2

# MQTT 参数
PROTOCOL="MQTT"
PORT=1883  # NanoMQ 默认 MQTT 端口
TIMEOUT=1  # 短超时以加速 afl-cov

# 启动 NanoMQ gcov 版本
$SERVER start &  # 如果需要配置文件，添加如 "$SERVER start -c nanomq.conf &"

SERVER_PID=$!  # 获取进程 ID

sleep 1  # 等待服务器启动并监听端口

# 用 aflnet-replay 重放测试用例到端口
aflnet-replay $TESTCASE $PROTOCOL $PORT $TIMEOUT

# 杀死服务器进程以释放资源
kill $SERVER_PID
wait $SERVER_PID  # 确保进程退出

/opt/afl-cov/afl-cov -d /opt/gcov_nanomq/out-mqtt/ --coverage-cmd "/opt/gcov_nanomq/wrapper.sh /opt/gcov_nanomq/build/nanomq/nanomq AFL_FILE" --code-dir . --enable-branch-coverage

root@571643732ab5:/opt/gcov_nanomq# /opt/afl-cov/afl-cov -d /opt/gcov_nanomq/out-mqtt/ --coverage-cmd "/opt/gcov_nanomq/wrapper.sh /opt/gcov_nanomq/build/nanomq/nanomq AFL_FILE" --code-dir . --enable-branch-coverage --afl-queue-id-limit 500 --overwrite
